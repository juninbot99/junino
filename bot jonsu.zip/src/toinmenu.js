const juninbotmenu = (prefix, pushname) => {
    return `◪ *Comandos Junin Bot*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}block
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}clearall`

}

exports.juninmenu = juninmenu